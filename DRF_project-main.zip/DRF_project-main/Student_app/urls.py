from django.urls import path
from .views import *

urlpatterns = [
    path("students/", StudentList.as_view()),
    path("students/add/", StudentAdd.as_view()),
    path("students/edit/<int:pk>/", StudentEdit.as_view()),
    path('students/delete/<int:pk>/', StudentDelete.as_view()),
]