import time
import datetime
import pygame as p
import pywhatkit as kit
import random
import pyautogui as pg
import re



# PYGAME
p.init()
p.display.set_caption("Loan Enrollment System")

screen = p.display.set_mode((800, 800))

img = p.image.load("loan.png")
img = p.transform.scale(img, (780, 700))

screen.blit(img, (10, 40))
p.display.update()

time.sleep(3)
p.quit()



print("========= Loan Enrollment System =========")

users = []
final_details = []

# NUMBER OF USERS
n = int(input("Enter number of persons: "))

# REGISTRATION
print("========= REGISTRATION OF USERS =========")

for i in range(n):

    print(f"\nEnter details for Person {i+1}")

    name = input("Enter your Name: ")
    age = int(input("Enter your Age: "))

    if age < 24:
        print("Your Age is low so you are not eligible for this loan")
        exit()
    else:
        print("Loan Eligible")

    gender = input("Enter your Gender (female/male): ")

    if gender not in ["female", "Female", "male", "Male"]:
        print("Invalid Gender")
        exit()
    else:
        print("Valid Gender")

    email = input("Enter your Email: ")
    password = input("Enter Password: ")

    if len(password) < 4:
        print("Invalid Password")
        exit()
    else:
        print("Valid Password")

    users.append({
        "name": name,
        "age": age,
        "gender": gender,
        "email": email,
        "password": password
    })



print("========= LOGIN USERS =========")

def login(users):
    attempts = 3

    while attempts > 0:
        user = input("User: ")
        pas = input("Password: ")

        for u in users:
            if u["name"] == user and u["password"] == pas:
                print("Login Successful")
                return u

        attempts -= 1
        print("Invalid login. Attempts left:", attempts)

    return None


#Login Persons With username and Pssword
for i in range(n):

    print(f"\n=========== Login Person {i+1} ===========")

    current_user = login(users)

    if not current_user:
        continue


    #User List
    print("\nWelcome", current_user["name"])

    loan_type = input("Enter loan type (personal/business/home): ").lower()

    
    # LOAN IMAGE
    #Personal loan 
    if loan_type in ["personal", "personal loan"]:

        p.init()
        screen = p.display.set_mode((370, 460))
        p.display.set_caption("Personal Loan")

        img = p.image.load("personal_loan.png")
        img = p.transform.scale(img, (370, 460))

        screen.fill((255, 255, 255))
        screen.blit(img, (10, 40))
        p.display.update()

        rate = 12
        
    #Business loan image shows
    elif loan_type in ["business", "business loan"]:

        p.init()
        screen = p.display.set_mode((500, 420))
        p.display.set_caption("Business Loan")

        img = p.image.load("business.png")
        img = p.transform.scale(img, (500, 420))

        screen.fill((255, 255, 255))
        screen.blit(img, (0, 0))
        p.display.update()

        rate = 10
     #Home loan image shows
    elif loan_type in ["home", "home loan"]:

        p.init()
        screen = p.display.set_mode((400, 300))
        p.display.set_caption("Home Loan")

        img = p.image.load("home.png")
        img = p.transform.scale(img, (400, 300))

        screen.fill((255, 255, 255))
        screen.blit(img, (0, 0))
        p.display.update()

        rate = 8

    else:
        print("Invalid loan type")
        continue

    time.sleep(3)
    p.quit()

    
 #salary checks
    salary = float(input("Enter Salary: "))

    if salary < 20000:
        print("Not Eligible")
        continue

    # OTP GENERATE WHATSAPP
    
    phone = input("Enter Phone Number: ")

    otp = random.randint(1000, 9999)

    print("Generated OTP:", otp)

    kit.sendwhatmsg_instantly(
        f"+91{phone}",
        f"Your OTP is: {otp}",
        wait_time=20,
        tab_close=False
    )

    print("OTP Sent Successfully")

    time.sleep(10)

    user_input = input("Enter OTP: ").strip()

    if user_input != str(otp):
        print("Invalid OTP Input")
        continue

    print("OTP Verified")


    #Original Details Added in Temporary defalut values

    
    print("=======================PROOF DETAILS========================")

    print("\nPlease provide your original proof documents for verification.")

    aadhaar = input("Enter Aadhaar Number: ").strip()

    pan = input("Enter PAN Number: ").strip().upper()

    account_number = input("Enter Account Number: ").strip()

    ifsc = input("Enter IFSC Code: ").strip().upper()

    # validate

    pan_pattern = r"^[A-Z]{5}[0-9]{4}[A-Z]{1}$"

    ifsc_pattern = r"^[A-Z]{4}0[A-Z0-9]{6}$"

    if (
            aadhaar.isdigit() and len(aadhaar) == 12 and
            re.match(pan_pattern, pan) and
            account_number.isdigit() and 9 <= len(account_number) <= 18 and
            re.match(ifsc_pattern, ifsc)
    ):
        print("Proof Details Submitted Successfully")
    else:
        print("Invalid Proof Details")
        continue




   #cibil score check
    print("=================== CIBIL CHECK ==================")

    payment_history = int(input("Enter Payment History (%): "))
    credit_utilization = int(input("Enter Credit Utilization (%): "))
    loan_history_years = int(input("Enter Loan History Years: "))

    score = 300

    if payment_history >= 95:
        score += 210
    elif payment_history >= 80:
        score += 150
    else:
        score += 50

    if credit_utilization <= 30:
        score += 180
    elif credit_utilization <= 70:
        score += 100
    else:
        score += 20

    score += min(loan_history_years * 10, 90)

    cibil = min(score, 900)

    print("CIBIL Score:", cibil)

    #  LOAN
    
    eligible_amount = 0

    if cibil >= 750:
        eligible_amount = salary * 5
    elif cibil >= 650:
        eligible_amount = salary * 3
    elif cibil >= 550:
        eligible_amount = salary * 2
    else:
        print("Loan Rejected")
        continue

    print("Eligible Amount:", eligible_amount)

    years = input("Enter Loan Years: ")
    years = int(years.replace("years", "").replace("year", "").strip())

    months = years * 12
    r = rate / (12 * 100)

    emi = (eligible_amount * r * (1 + r) ** months) / ((1 + r) ** months - 1)

    print("EMI:", round(emi, 2))

    
#Loan ID and reference number generation

    
    # ================= LOAN DETAILS =================
    loan_id = "LOAN" + str(random.randint(100000, 999999))
    ref_no = "REF" + str(random.randint(10000000, 99999999))
    date = datetime.datetime.now().strftime("%d-%m-%Y %H:%M:%S")

    print("Loan ID Generated:", loan_id)
    print("Reference Number:", ref_no)
    print("Date:", date)



    
    bank_name = "Indian Bank"
    branch_name = "Chennai Main Branch"

    final_message = f"""
LOAN APPROVED / CONFIRMED

Bank Name : {bank_name}
Branch Name : {branch_name}
Loan ID : {loan_id}
Reference No : {ref_no}
Date : {date}
Customer Name : {current_user['name']}
Loan Type : {loan_type}
CIBIL Score : {cibil}
Eligible Amount : {eligible_amount}
Interest Rate : {rate}%
EMI : {round(emi, 2)}
Loan Period : {years} Years

Status : APPROVED
"""

    kit.sendwhatmsg_instantly(
        f"+91{phone}",
        final_message,
        wait_time=20,
        tab_close=False
    )

    print("Confirmation message sent to WhatsApp")

    
    # STORE DATA (SAFE)
    final_details.append({
        "name": current_user["name"],
        "loan_type": loan_type,
        "emi": round(emi, 2),
        "years": years,
        "months": months
    })


# FINAL REPORT
print("\n=========== FINAL ALL USERS DETAILS ===========")

for d in final_details:
    print(d)
